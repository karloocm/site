const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');
const response = document.getElementById('response');

// Acción para el botón "Sí"
yesBtn.addEventListener('click', () => {
    response.style.display = 'block';
    response.textContent = "¡Sabía que dirías que síii! ❤️Te amo como no tienes ideaa😽❤️";
});

// Acción para el botón "No"
noBtn.addEventListener('mouseover', () => {
    const randomX = Math.random() * (window.innerWidth - noBtn.offsetWidth);
    const randomY = Math.random() * (window.innerHeight - noBtn.offsetHeight);

    noBtn.style.left = `${randomX}px`;
    noBtn.style.top = `${randomY}px`;
});